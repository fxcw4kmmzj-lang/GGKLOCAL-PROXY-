const { v4: uuidv4 } = require('uuid');
const BedrockProxy = require('../proxy/BedrockProxy');
const portAllocator = require('../networking/portAllocator');
const database = require('../config/database');
const config = require('../config/config');

class SessionManager {
  constructor() {
    this.sessions = new Map();
    this.startCleanupTask();
  }
  
  async createSession(userId, targetIp, targetPort) {
    try {
      // Validate inputs
      if (!targetIp || !targetPort) {
        throw new Error('Target IP and port are required');
      }
      
      if (targetPort < 1 || targetPort > 65535) {
        throw new Error('Invalid target port');
      }
      
      // Allocate proxy port
      const proxyPort = portAllocator.allocate();
      
      // Generate session ID
      const sessionId = uuidv4();
      
      // Create proxy instance
      const proxy = new BedrockProxy(sessionId, targetIp, targetPort, proxyPort);
      
      // Start proxy
      await proxy.start();
      
      // Store session
      const session = {
        id: sessionId,
        userId,
        targetIp,
        targetPort,
        proxyPort,
        proxy,
        createdAt: Date.now(),
        lastActivity: Date.now(),
        status: 'active'
      };
      
      this.sessions.set(sessionId, session);
      
      // Save to database
      await database.run(
        `INSERT INTO sessions (id, user_id, target_ip, target_port, proxy_port, status)
         VALUES (?, ?, ?, ?, ?, ?)`,
        [sessionId, userId, targetIp, targetPort, proxyPort, 'active']
      );
      
      // Set up proxy event handlers
      proxy.on('clientConnected', () => {
        this.updateSessionActivity(sessionId);
      });
      
      proxy.on('packetForwarded', () => {
        this.updateSessionActivity(sessionId);
      });
      
      console.log(`✓ Session created: ${sessionId}`);
      console.log(`  User: ${userId}`);
      console.log(`  Target: ${targetIp}:${targetPort}`);
      console.log(`  Proxy Port: ${proxyPort}`);
      
      return {
        sessionId,
        proxyPort,
        targetIp,
        targetPort,
        proxyIp: config.domain
      };
    } catch (error) {
      console.error('Error creating session:', error);
      throw error;
    }
  }
  
  updateSessionActivity(sessionId) {
    const session = this.sessions.get(sessionId);
    if (session) {
      session.lastActivity = Date.now();
      
      // Update database
      database.run(
        'UPDATE sessions SET last_activity = CURRENT_TIMESTAMP WHERE id = ?',
        [sessionId]
      ).catch(err => console.error('Error updating session activity:', err));
    }
  }
  
  async endSession(sessionId) {
    const session = this.sessions.get(sessionId);
    
    if (!session) {
      throw new Error('Session not found');
    }
    
    try {
      // Stop proxy
      await session.proxy.stop();
      
      // Release port
      portAllocator.release(session.proxyPort);
      
      // Update database
      await database.run(
        'UPDATE sessions SET status = ?, ended_at = CURRENT_TIMESTAMP WHERE id = ?',
        ['ended', sessionId]
      );
      
      // Remove from active sessions
      this.sessions.delete(sessionId);
      
      console.log(`✓ Session ended: ${sessionId}`);
      
      return true;
    } catch (error) {
      console.error('Error ending session:', error);
      throw error;
    }
  }
  
  getSession(sessionId) {
    return this.sessions.get(sessionId);
  }
  
  getUserSessions(userId) {
    const userSessions = [];
    for (const [id, session] of this.sessions.entries()) {
      if (session.userId === userId) {
        userSessions.push({
          id: session.id,
          targetIp: session.targetIp,
          targetPort: session.targetPort,
          proxyPort: session.proxyPort,
          createdAt: session.createdAt,
          lastActivity: session.lastActivity,
          status: session.status,
          stats: session.proxy.getStats()
        });
      }
    }
    return userSessions;
  }
  
  getAllSessions() {
    const allSessions = [];
    for (const [id, session] of this.sessions.entries()) {
      allSessions.push({
        id: session.id,
        userId: session.userId,
        targetIp: session.targetIp,
        targetPort: session.targetPort,
        proxyPort: session.proxyPort,
        createdAt: session.createdAt,
        lastActivity: session.lastActivity,
        status: session.status,
        stats: session.proxy.getStats()
      });
    }
    return allSessions;
  }
  
  getStats() {
    return {
      activeSessions: this.sessions.size,
      allocatedPorts: portAllocator.getAllocatedCount(),
      availablePorts: portAllocator.getAvailableCount()
    };
  }
  
  async cleanup() {
    console.log('Running session cleanup...');
    
    const inactiveTimeout = config.proxy.inactiveTimeout;
    const now = Date.now();
    const sessionsToEnd = [];
    
    for (const [sessionId, session] of this.sessions.entries()) {
      if (now - session.lastActivity > inactiveTimeout) {
        console.log(`Session ${sessionId} is inactive, ending...`);
        sessionsToEnd.push(sessionId);
      }
    }
    
    for (const sessionId of sessionsToEnd) {
      try {
        await this.endSession(sessionId);
      } catch (error) {
        console.error(`Error ending session ${sessionId}:`, error);
      }
    }
    
    if (sessionsToEnd.length > 0) {
      console.log(`✓ Cleaned up ${sessionsToEnd.length} inactive session(s)`);
    }
  }
  
  startCleanupTask() {
    setInterval(() => {
      this.cleanup().catch(err => {
        console.error('Cleanup task error:', err);
      });
    }, config.cleanup.interval);
    
    console.log('✓ Cleanup task started');
  }
}

module.exports = new SessionManager();