const express = require('express');
const router = express.Router();
const sessionManager = require('../sessions/sessionManager');
const authenticate = require('../middleware/auth');

// Create new proxy session
router.post('/create', authenticate, async (req, res) => {
  try {
    const { targetIp, targetPort } = req.body;
    const userId = req.user.id;
    
    if (!targetIp || !targetPort) {
      return res.status(400).json({
        success: false,
        error: 'Target IP and port are required'
      });
    }
    
    const session = await sessionManager.createSession(
      userId,
      targetIp,
      parseInt(targetPort)
    );
    
    res.json({
      success: true,
      message: 'Proxy session created',
      session
    });
  } catch (error) {
    res.status(500).json({
      success: false,
      error: error.message
    });
  }
});

// End session
router.post('/end/:sessionId', authenticate, async (req, res) => {
  try {
    const { sessionId } = req.params;
    const userId = req.user.id;
    
    const session = sessionManager.getSession(sessionId);
    
    if (!session) {
      return res.status(404).json({
        success: false,
        error: 'Session not found'
      });
    }
    
    // Check if user owns this session
    if (session.userId !== userId) {
      return res.status(403).json({
        success: false,
        error: 'Unauthorized'
      });
    }
    
    await sessionManager.endSession(sessionId);
    
    res.json({
      success: true,
      message: 'Session ended'
    });
  } catch (error) {
    res.status(500).json({
      success: false,
      error: error.message
    });
  }
});

// Get user's sessions
router.get('/my-sessions', authenticate, (req, res) => {
  try {
    const userId = req.user.id;
    const sessions = sessionManager.getUserSessions(userId);
    
    res.json({
      success: true,
      sessions
    });
  } catch (error) {
    res.status(500).json({
      success: false,
      error: error.message
    });
  }
});

// Get session details
router.get('/:sessionId', authenticate, (req, res) => {
  try {
    const { sessionId } = req.params;
    const userId = req.user.id;
    
    const session = sessionManager.getSession(sessionId);
    
    if (!session) {
      return res.status(404).json({
        success: false,
        error: 'Session not found'
      });
    }
    
    // Check if user owns this session
    if (session.userId !== userId) {
      return res.status(403).json({
        success: false,
        error: 'Unauthorized'
      });
    }
    
    res.json({
      success: true,
      session: {
        id: session.id,
        targetIp: session.targetIp,
        targetPort: session.targetPort,
        proxyPort: session.proxyPort,
        createdAt: session.createdAt,
        lastActivity: session.lastActivity,
        status: session.status,
        stats: session.proxy.getStats()
      }
    });
  } catch (error) {
    res.status(500).json({
      success: false,
      error: error.message
    });
  }
});

module.exports = router;